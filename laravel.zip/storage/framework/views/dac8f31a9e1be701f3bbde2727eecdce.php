;

<?php $__env->startSection('content'); ?>
    <div class="row mx-1">
        <div class="bg-light rounded h-100 p-4">
            <?php if(session('message')): ?>
                <div class="alert alert-success mb-3">
                    <h5><?php echo e(session('message')); ?></h5>
                </div>
            <?php endif; ?>
            <h6 class="mb-4">Brand List</h6>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <?php if($user->role_as == '0'): ?>
                                    <label for="" class="badge btn-primary">user</label>
                                <?php else: ?>
                                <label for="" class="badge btn-success">admin</label>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a class="btn btn-success btn-sm"
                                    href="<?php echo e('/admin/users/' . $user->id . '/edit'); ?>">Edit</a>
                                <a class="btn btn-danger btn-sm" href="<?php echo e('/admin/users/' . $user->id . '/delete'); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">
                                <div class="text-center">
                                    <h5>No brands found. <a href="/admin/categories/create">Add</a> category</h5>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ecommerce\ecommerce_portofolio\resources\views/admin/users/index.blade.php ENDPATH**/ ?>