;

<?php $__env->startSection('content'); ?>
    <div class="row mx-1">
        <div class="bg-light rounded h-100 p-4">
            <?php if(session('message')): ?>
                <div class="alert alert-success mb-3">
                    <h5><?php echo e(session('message')); ?></h5>
                </div>
            <?php endif; ?>
            <h6 class="mb-4">Product List <a href="/admin/products/create" class="btn btn-primary float-end">Add product</a></h6>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Slug</th>
                        <th>Small Description</th>
                        <th>Description</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($product->id); ?></td>
                            <td><?php echo e($product->name); ?></td>
                            <td><?php echo e($product->slug); ?></td>
                            <td><?php echo e($product->small_description); ?></td>
                            <td><?php echo e($product->description); ?></td>
                            <td><?php echo e($product->price); ?></td>
                            <td><?php echo e($product->quantity); ?></td>
                            <td>
                                <a class="btn btn-success btn-sm"
                                    href="<?php echo e('/admin/products/' . $product->id . '/edit'); ?>">Edit</a>
                                <a class="btn btn-danger btn-sm"
                                    href="<?php echo e('/admin/products/' . $product->id . '/delete'); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">
                                <div class="text-center">
                                    <h5>No categories found. <a href="/admin/products/create">Add</a> product</h5>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ecommerce\ecommerce_portofolio\resources\views/admin/products/index.blade.php ENDPATH**/ ?>