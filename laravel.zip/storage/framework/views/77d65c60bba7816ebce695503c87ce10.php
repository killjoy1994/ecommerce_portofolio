

<?php $__env->startSection('content'); ?>
    <div>
        <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php echo e($id == 0 ? 'active' : ''); ?>" data-bs-interval="10000">
                        <img src="<?php echo e(asset($slider->image)); ?>" class="d-block w-100" style="height: 550px" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h3 class="fs-1 text-light"><?php echo e($slider->title); ?></h3>
                            <p class="fs-4"><?php echo e($slider->description); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>

        <div class="py-5 bg-white">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8 text-center">
                        <h4>Welcome, Lorem ipsum dolor sit amet consectetur.</h4>
                        <div class="underline"></div>
                        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quod voluptatum, laboriosam quam
                            quaerat
                            voluptatem voluptas. Est praesentium quod distinctio delectus! Eveniet ex atque quae, totam
                            mollitia, earum culpa quisquam officia, officiis possimus eum natus hic aspernatur omnis
                            adipisci
                            eius minima?</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="container py-5">
            <div class="row">
                <div class="col-md-12">
                    <h4>Trending Products <a href="/trending" class="float-end text-secondary fs-5">View more</a></h4>
                </div>
                <div class="col-md-12 mt-3">
                    <div class="owl-carousel owl-theme">
                        <?php $__currentLoopData = $trendings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <div class="position-relative">
                                    <a href="<?php echo e('/categories/' . $trending->category->slug . '/' . $trending->slug); ?>">
                                        <img src="<?php echo e(asset($trending->productImages[0]->image)); ?>" height="200px"
                                            alt="">
                                    </a>
                                </div>
                                <div class="d-flex justify-content-between mt-2">
                                    <div>
                                        <h5 class="mt-3 text-dark">Rp. <?php echo number_format($trending->price,0,',','.'); ?></h5>
                                        <a href="<?php echo e('/categories/' . $trending->category->slug . '/' . $trending->slug); ?>">
                                            <p class="m-0 fw-bold"><?php echo e($trending->name); ?></p>
                                        </a>
                                        <p class="m-0"><?php echo e($trending->small_description); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="container py-5">
            <div class="row">
                <div class="col-md-12">
                    <h4>Featured Products <a href="/featured" class="float-end text-secondary fs-5">View more</a></h4>
                </div>
                <div class="col-md-12 mt-3">
                    <div class="owl-carousel owl-theme">
                        <?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $featuredItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <div class="position-relative">
                                    <img src="<?php echo e(asset($featuredItem->productImages[0]->image)); ?>" height="200px"
                                        alt="">
                                    
                                </div>
                                <div class="d-flex justify-content-between mt-2">
                                    <div>
                                        <h5 class="mt-3 text-dark">Rp. <?php echo number_format($featuredItem->price,0,',','.'); ?></h5>
                                        <a href="<?php echo e(Request::url() . '/' . $featuredItem->slug); ?>">
                                            <p class="m-0 fw-bold"><?php echo e($featuredItem->name); ?></p>
                                        </a>
                                        <p class="m-0"><?php echo e($featuredItem->small_description); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $('.owl-carousel').owlCarousel({
            loop: true,
            margin: 10,
            nav: true,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 3
                },
                1000: {
                    items: 5
                }
            }
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ecommerce\ecommerce_portofolio\resources\views/frontend/index.blade.php ENDPATH**/ ?>