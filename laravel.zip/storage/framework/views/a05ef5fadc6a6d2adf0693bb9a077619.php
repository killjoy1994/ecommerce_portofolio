;

<?php $__env->startSection('content'); ?>
    <div class="h-100">
        <div class="container">
            <h3 class="fs-2 text-secondary fw-4">My Orders</h3>
            <hr>
            <div class="mt-4 row">
               <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Tracking No</th>
                        <th>Username</th>
                        <th>Order Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($order->id); ?></td>
                            <td><?php echo e($order->tracking_no); ?></td>
                            <td><?php echo e($order->fullname); ?></td>
                            <td><?php echo e($order->created_at); ?></td>
                            <td><?php echo e($order->status_message); ?></td>
                            <td>
                                <a href="<?php echo e('/orders/' . $order->id); ?>" class="btn btn-primary btn-sm">View</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
               </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ecommerce\ecommerce_portofolio\resources\views/frontend/orders.blade.php ENDPATH**/ ?>