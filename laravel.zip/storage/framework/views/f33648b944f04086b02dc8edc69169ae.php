;

<?php $__env->startSection('content'); ?>
    <div class="h-100">
        <div class="container">
            <h3 class="fs-2 fw-4">Results</h3>
            <div class="mt-4 row">
                <?php $__currentLoopData = $searchProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="">
                    <div class="position-relative">
                        <a href="<?php echo e('/categories/' . $product->category->slug . '/' . $product->slug); ?>">
                            <img src="<?php echo e(asset($product->productImages[0]->image)); ?>" height="200px"
                                alt="">
                        </a>
                    </div>
                    <div class="d-flex justify-content-between mt-2">
                        <div>
                            <h5 class="mt-3 text-dark">Rp. <?php echo number_format($product->price,0,',','.'); ?></h5>
                            <a href="<?php echo e('/categories/' . $product->category->slug . '/' . $product->slug); ?>">
                                <p class="m-0 fw-bold"><?php echo e($product->name); ?></p>
                            </a>
                            <p class="m-0"><?php echo e($product->small_description); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ecommerce\ecommerce_portofolio\resources\views/frontend/search.blade.php ENDPATH**/ ?>