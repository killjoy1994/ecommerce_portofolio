<nav class="navbar fixed-top  navbar-expand-lg navbar-light bg-light px-3 py-2 shadow-sm">
    <div class="container-fluid mt-3">
        <div class="d-flex justify-content-between w-100">
            <div class="d-flex align-items-center">
                <a class="navbar-brand fs-2" href="#">
                    MyMarket.
                </a>
                <form action="/search" class="d-flex m-0 ms-5" style="width: 300px">
                    <?php echo csrf_field(); ?>
                    <input class="form-control me-2" name="search" type="search" placeholder="Search"
                        aria-label="Search">
                    <button class="border-0 bg-transparent" type="submit"><i
                            class="fas fa-search fs-5 text-secondary"></i></button>
                </form>
            </div>
            <div>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="d-flex align-items-center">
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0 d-flex align-items-center">
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->route()->uri == '/' ? 'active-link' : ''); ?> fs-5"
                                    aria-current="page" href="/">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link fs-5 <?php echo e(request()->route()->uri == 'categories' ? 'active-link' : ''); ?>"
                                    href="/categories">All Categories</a>
                            </li>
                            <?php if(auth()->guard()->guest()): ?>
                                <?php if(Route::has('login')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link fs-5 <?php echo e(request()->route()->uri == 'login' ? 'active-link' : ''); ?>" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                    </li>
                                <?php endif; ?>

                                <?php if(Route::has('register')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link fs-5 <?php echo e(request()->route()->uri == 'register' ? 'active-link' : ''); ?>" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php else: ?>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(request()->route()->uri == 'cart' ? 'active-link' : ''); ?> fs-5"
                                        href="/cart">Cart</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo e(request()->route()->uri == 'orders' ? 'active-link' : ''); ?> fs-5"
                                        href="/orders">Orders</a>
                                </li>
                                <li>
                                    <div class="ms-3 d-flex align-items-center">
                                        
                                        
                                        <div class="btn-group dropstart">
                                            <div class="dropdown-toggle" type="button" id="dropdownMenuButton1"
                                                data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="fas fa-user fs-5 text-secondary"></i>
                                            </div>
                                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                                <li><a class="dropdown-item" href="#">
                                                        <?php if(Auth::check()): ?>
                                                            <?php echo e(Auth::user()->name); ?>

                                                        <?php endif; ?>
                                                    </a></li>
                                                <li>
                                                    <div class="dropdown-item p-0">
                                                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                                            onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();">
                                                            <?php echo e(__('Logout')); ?>

                                                        </a>

                                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>"
                                                            method="POST" class="d-none">
                                                            <?php echo csrf_field(); ?>
                                                        </form>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </li>
                            <?php endif; ?>



                        </ul>

                    </div>

                </div>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH D:\Ecommerce\ecommerce_portofolio\resources\views/layouts/include/frontend/navbar.blade.php ENDPATH**/ ?>