

<?php $__env->startSection('content'); ?>
    <div class="h-100 mt-5">
        <div class="container">
            <h3 class="fs-3 fw-4 text-secondary">Our Products</h3>
            <div class="row">
                <div class="col-md-3 bg-light rounded py-3">
                    <form action="<?php echo e(route('products.filter')); ?>" method="GET">
                        <!-- Brands filter -->
                        <h5 class="text-secondary">Brands</h5>
                        <hr>
                        <?php $__empty_1 = true; $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="brands[]"
                                    <?php echo e(isset($selectedBrands) && in_array($brand->name, $selectedBrands) ? 'checked' : ''); ?>

                                    value="<?php echo e($brand->name); ?>" id="brand_<?php echo e($brand->name); ?>">
                                <label class="form-check-label" for="brand_<?php echo e($brand->name); ?>">
                                    <?php echo e($brand->name); ?>

                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div>
                                <h4 class="fs-5 text-secondary">No brands found in this category.</h4>
                            </div>
                        <?php endif; ?>

                        <!-- Price filter -->
                        <?php if($products->count() > 0): ?>
                            <div class="mt-4">
                                <h5 class="text-secondary">Price</h5>
                                <hr>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="price_order" value="asc"
                                        id="price_asc" <?php echo e(isset($priceOrder) && $priceOrder == 'asc' ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="price_asc">
                                        Low to high
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="price_order" value="desc"
                                        id="price_desc" <?php echo e(isset($priceOrder) && $priceOrder == 'desc' ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="price_desc">
                                        High to low
                                    </label>
                                </div>
                            </div>
                        <?php endif; ?>

                        <!-- Submit button -->
                        <?php if($products->count() > 0): ?>
                            <div class="mt-5 row px-3 g-2">
                                <div class="col-md-6">
                                    <button type="submit" class="btn btn-primary w-100">Apply Filters</button>
                                </div>
                                <div class="col-md-6">
                                    <a class="btn btn-warning text-light w-100"
                                        href="<?php echo e('/categories/' . $products[0]->category->slug); ?>">Clear Filters</a>
                                </div>
                            </div>
                        <?php endif; ?>
                    </form>
                </div>
                <div class="col-md-9">
                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-md-4 mb-5">
                                <a href="<?php echo e('/categories/' . $product->category->slug . '/' . $product->slug); ?>">
                                    <img src="<?php echo e(asset($product->productImages[0]->image)); ?>" width="100%" height="250px"
                                        alt="">
                                </a>
                                <div>
                                    <h5 class="mt-3 text-dark">Rp. <?php echo number_format($product->price,0,',','.'); ?></h5>
                                    <a href="<?php echo e('/categories/' . $product->category->slug . '/' . $product->slug); ?>">
                                        <p class="m-0 fw-bold"><?php echo e($product->name); ?></p>
                                    </a>
                                    <p class="m-0"><?php echo e($product->small_description); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div>
                                <h2 class="text-secondary text-center">No products found.</h2>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ecommerce\ecommerce_portofolio\resources\views/frontend/products.blade.php ENDPATH**/ ?>