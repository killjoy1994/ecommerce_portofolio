;

<?php $__env->startSection('content'); ?>
    <div class="h-100">
        <div class="container">
            <h3 class="fs-2 fw-4">All Categories</h3>
            <div class="mt-4 row">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 mb-5">
                        <a href="<?php echo e(Request::url() . '/' . $category->slug); ?>">
                            <img src="<?php echo e(asset('storage/category/'.$category->image)); ?>" width="100%" height="250px" alt="">
                        </a>
                        <a class="text-decoration-none" href="<?php echo e(Request::url() . '/' . $category->slug); ?>">
                            <h4 class="text-secondary bg-light py-3 text-center"><?php echo e($category->name); ?></h4>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ecommerce\ecommerce_portofolio\resources\views/frontend/categories.blade.php ENDPATH**/ ?>