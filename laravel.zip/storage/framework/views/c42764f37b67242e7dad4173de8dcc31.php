

<?php $__env->startSection('content'); ?>
    <div class="row mx-1">
        <div class="col-md-12">
            <div class="bg-light rounded h-100 p-4">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <h4 class="mb-4 text-secondary">Edit Product</h4>
                <form action="<?php echo e(url('admin/products/'. $product->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home"
                                type="button" role="tab" aria-controls="home" aria-selected="true">Home</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="details-tab" data-bs-toggle="tab" data-bs-target="#details"
                                type="button" role="tab" aria-controls="details" aria-selected="false">Details</button>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="floatingInput" value="<?php echo e($product->name); ?>"
                                    name="name" placeholder="name@example.com">
                                <label for="floatingInput">Product Name</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="floatingInput" value="<?php echo e($product->slug); ?>"
                                    name="slug" placeholder="name@example.com">
                                <label for="floatingInput">Product Slug</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="floatingInput"
                                    value="<?php echo e($product->small_description); ?>" name="small_description"
                                    placeholder="name@example.com">
                                <label for="floatingInput">Small description</label>
                            </div>
                            <div class="form-floating mb-3">
                                <textarea class="form-control" name="description" value="<?php echo e($product->description); ?>" placeholder="Leave a comment here"
                                    id="floatingTextarea" style="height: 150px;"><?php echo e($product->description); ?></textarea>
                                <label for="floatingTextarea">Description</label>
                            </div>
                            <div class="mb-3">
                                <select name="category_id" class="form-select form-select-md mb-3"
                                    aria-label=".form-select-md example" id="category">
                                    <option>Select Category</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"
                                            <?php echo e($category->id == $product->category_id ? 'selected' : ''); ?>>
                                            <?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <select class="form-select form-select-md mb-3"
                                    aria-label=".form-select-md example" name="brand" id="brand">
                                    
                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($brand->name); ?>"
                                        <?php echo e($brand->name == $product->brand ? 'selected' : ''); ?>>
                                        <?php echo e($brand->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="details" role="tabpanel" aria-labelledby="details-tab">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="number" class="form-control" id="floatingInput" value="<?php echo e($product->price); ?>" name="price"
                                            placeholder="name@example.com" min="1">
                                        <label for="floatingInput">Price</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="number" class="form-control" id="floatingInput" value="<?php echo e($product->quantity); ?>" name="quantity"
                                            placeholder="name@example.com" min="1">
                                        <label for="floatingInput">Quantity</label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-check mb-3">
                                <input class="form-check-input" <?php echo e($product->trending == '1' ? "checked" : ""); ?> type="checkbox" name="trending"
                                    id="flexCheckDefault">
                                <label class="form-check-label" for="flexCheckDefault">
                                    Trending
                                </label>
                            </div>
                            <div class="form-check mb-3">
                                <input class="form-check-input" <?php echo e($product->featured == '1' ? "checked" : ""); ?> type="checkbox" name="featured"
                                    id="flexCheckDefault2">
                                <label class="form-check-label" for="flexCheckDefault2">
                                    Featured
                                </label>
                            </div>
                            <div class="row mb-3">
                                <div class="mb-3 col-md-12">
                                    <label for="formFileMultiple" class="form-label">Product Images</label>
                                    <input class="form-control" name="image[]" type="file" id="formFileMultiple"
                                        multiple>
                                </div>
                                <div class="row">
                                    <?php $__currentLoopData = $product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageFile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-2">
                                            <img src="<?php echo e(asset($imageFile->image)); ?>" style="width: 100px; height:100px"
                                                alt="">
                                            <a href="<?php echo e('/admin/product-image/' . $imageFile->id . '/delete'); ?>">remove</a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $('#category').change(function() {
            // console.log("Hallo")
            var categoryID = $(this).val();
            if (categoryID) {
                $.ajax({
                    type: "GET",
                    url: "/admin/getbrand?categoryID=" + categoryID,
                    dataType: 'JSON',
                    success: function(res) {
                        if (res.length !== 0) {
                            console.log(res);
                            $("#brand").empty();
                            // $("#category").append('<option>---Pilih Brand---</option>');
                            $.each(res, function(name, id) {
                                $("#brand").append(`<option value=${name}>${name}</option>`);
                            });
                        } else {
                            console.log(res);
                            $("#brand").empty();
                            // console.log("NOL VALUE")
                            $("#brand").append('<option value=""> This category has no brand</option>');
                        }
                    }
                });
            } else {
                $("#brand").empty();
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ecommerce\ecommerce_portofolio\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>