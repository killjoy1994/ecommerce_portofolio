;

<?php $__env->startSection('content'); ?>
    <div class="row mx-1">
        <div class="bg-light rounded h-100 p-4">
            <?php if(session('message')): ?>
                <div class="alert alert-success mb-3">
                    <h5><?php echo e(session('message')); ?></h5>
                </div>
            <?php endif; ?>
            <h6 class="mb-4">Brand List <a href="/admin/brands/create" class="btn btn-primary float-end">Add brand</a></h6>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Slug</th>
                        <th>Category</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($brand->id); ?></td>
                            <td><?php echo e($brand->name); ?></td>
                            <td><?php echo e($brand->slug); ?></td>
                            <td><?php echo e($brand->category->name); ?></td>
                            <td>
                                <a class="btn btn-success btn-sm"
                                    href="<?php echo e('/admin/categories/' . $brand->id . '/edit'); ?>">Edit</a>
                                <a class="btn btn-danger btn-sm" href="<?php echo e('/admin/categories/' . $brand->id . '/delete'); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">
                                <div class="text-center">
                                    <h5>No brands found. <a href="/admin/categories/create">Add</a> category</h5>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ecommerce\ecommerce_portofolio\resources\views/admin/brand/index.blade.php ENDPATH**/ ?>