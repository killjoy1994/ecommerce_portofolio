;

<?php $__env->startSection('content'); ?>
    <div class="row mx-1">
        <div class="bg-light rounded h-100 p-4">
            <?php if(session('message')): ?>
                <div class="alert alert-success mb-3">
                    <h5><?php echo e(session('message')); ?></h5>
                </div>
            <?php endif; ?>
            <h6 class="mb-4">Category List
                <a href="/admin/categories/create" class="btn btn-primary float-end">Add category</a>
            </h6>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Slug</th>
                        <th>Description</th>
                        <th>Image</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($category->id); ?></td>
                            <td><?php echo e($category->name); ?></td>
                            <td><?php echo e($category->slug); ?></td>
                            <td><?php echo e($category->description); ?></td>
                            <td>
                                <div style="width: 100px; height: 60px">
                                    <img style="width: 100%; height: 100%"
                                        src="<?php echo e(asset('storage/category/' . $category->image)); ?>" alt="">
                                </div>

                            </td>
                            <td>
                                <a class="btn btn-success btn-sm"
                                    href="<?php echo e('/admin/categories/' . $category->id . '/edit'); ?>">Edit</a>
                                <a class="btn btn-danger btn-sm"
                                    href="<?php echo e('/admin/categories/' . $category->id . '/delete'); ?>">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">
                                <div class="text-center">
                                    <h5>No categories found. <a href="/admin/categories/create">Add</a> category</h5>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ecommerce\ecommerce_portofolio\resources\views/admin/category/index.blade.php ENDPATH**/ ?>