

<?php $__env->startSection('content'); ?>
    <?php if(session('message')): ?>
        <div class="alert alert-success"><?php echo e(session('message')); ?></div>
    <?php endif; ?>
    <h1>HALLO DASHBOARD</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ecommerce\ecommerce_portofolio\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>